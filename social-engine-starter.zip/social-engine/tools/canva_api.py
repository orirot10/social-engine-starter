def call(*args, **kwargs):
    return {"ok": True, "args": args, "kwargs": kwargs}
