from flows.daily_loop import daily_loop

if __name__ == "__main__":
    report = daily_loop()
    print(report)
