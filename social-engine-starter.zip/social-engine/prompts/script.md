Persona: {persona_json} Product: {product_json}
Generate 3 short-form scripts (<=60s): {voiceover_text, beats, b-roll, caption, 8-12 hashtags, thumbnail_prompt}.